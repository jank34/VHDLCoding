
#include "apint_arith.h"

void apint_arith(signed char  inA, signed char   inB, signed char opSel,
		signed char  *out) {

	switch (opSel){
	case 1:
	*out = inA + inB;
	break;

	case 2:
	*out = inA - inB;
	break;

	case 3:
	*out = inA * inB;
	break;

	case 4:
	*out = inA / inB;
	break;
	}
} 


