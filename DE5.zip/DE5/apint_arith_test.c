
#include "apint_arith.h"
 
int main () {
	signed char   inA;
	signed char   inB;
	signed char  out;
	signed char opSel;



    inA = 8;
    inB = 4;
    opSel = 1;

		// Call the function to operate on the data
    apint_arith(inA,inB,opSel,&out);
	printf("%d+%d=%d;\n", inA, inB, out);

	 inA = 9;
	 inB = 5;
	 opSel = 2;
	 apint_arith(inA,inB,opSel,&out);
	 printf("%d-%d=%d;\n", inA, inB, out);

	 inA = 10;
     inB = 6;
     opSel = 3;
     apint_arith(inA,inB,opSel,&out);
	 printf("%d*%d=%d;\n", inA, inB, out);


	 inA = 11;
     inB = 7;
     opSel = 4;
     apint_arith(inA,inB,opSel,&out);
     printf("%d/%d=%d;\n", inA, inB, out);


}

